#!/usr/bin/env bash
set -euo pipefail
sudo insmod mgpu.ko || true
