# mgpu GEN-1 Skeleton

Minimal render-only FPGA GPU driver (char device MVP) + userspace HAL/tools + FW YAML + debug-first scaffolding.
See `docs/` and `kernel/drivers/gpu/mgpu/`.
