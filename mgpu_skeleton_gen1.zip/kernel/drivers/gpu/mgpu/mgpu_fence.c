/* mgpu_fence.c - GEN1 skeleton */
#include <linux/module.h>
#include <linux/kernel.h>
#include "mgpu_mmio.h"

/* TODO: implement mgpu_fence */
