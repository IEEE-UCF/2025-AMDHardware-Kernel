#!/usr/bin/env bash
# enable dynamic debug / tracepoints (skeleton)
