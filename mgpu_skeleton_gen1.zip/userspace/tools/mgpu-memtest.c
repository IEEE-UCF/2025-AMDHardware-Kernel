/* memtest skeleton */
int main(){return 0;}