print('regdump skeleton')
