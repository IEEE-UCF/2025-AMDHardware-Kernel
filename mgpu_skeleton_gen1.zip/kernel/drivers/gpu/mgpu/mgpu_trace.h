/* mgpu_trace.h - GEN1 skeleton TRACEPOINTS placeholder */
#ifndef MGPU_TRACE_H
#define MGPU_TRACE_H
/* TODO: TRACE_EVENT definitions */
#endif
