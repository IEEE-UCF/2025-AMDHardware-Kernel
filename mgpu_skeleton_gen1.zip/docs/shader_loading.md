# shader binary format and flow (skeleton)
