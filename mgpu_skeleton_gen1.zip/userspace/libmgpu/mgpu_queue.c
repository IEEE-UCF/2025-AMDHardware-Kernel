/* Queue helpers skeleton */
