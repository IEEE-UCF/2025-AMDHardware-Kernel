# debugfs, tracepoints, dev_coredump (skeleton)
