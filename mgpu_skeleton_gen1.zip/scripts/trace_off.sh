#!/usr/bin/env bash
# disable tracing (skeleton)
