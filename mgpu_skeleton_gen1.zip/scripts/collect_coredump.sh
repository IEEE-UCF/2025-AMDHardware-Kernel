#!/usr/bin/env bash
# fetch dev_coredump (skeleton)
