/* BO helpers skeleton */
