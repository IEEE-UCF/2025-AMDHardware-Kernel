/* mgpuctl skeleton - info/regs/bo/submit/wait/health */
int main(){return 0;}