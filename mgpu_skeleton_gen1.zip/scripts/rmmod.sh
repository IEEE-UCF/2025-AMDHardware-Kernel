#!/usr/bin/env bash
set -euo pipefail
sudo rmmod mgpu || true
