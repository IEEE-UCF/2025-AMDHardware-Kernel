# platform vs PCI, cache hints (skeleton)
