# pipeline state bindings (skeleton)
