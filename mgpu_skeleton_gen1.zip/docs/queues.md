# command buffer ABI (skeleton)
