/* Auto-generated from fw/registers.yaml (placeholder) */
#ifndef MGPU_MMIO_H
#define MGPU_MMIO_H
#define MGPU_REG_VERSION        0x0000
#define MGPU_REG_CAPS           0x0004
#define MGPU_REG_DOORBELL_BASE  0x0100
#define MGPU_REG_FENCE_COUNTER  0x0200
#define MGPU_INSTR_MEM_BASE     0x8000  /* placeholder */
#define MGPU_INSTR_MEM_SIZE     0x2000  /* placeholder */
#endif
