/* submit microbench */
int main(){return 0;}