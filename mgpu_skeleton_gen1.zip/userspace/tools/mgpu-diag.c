/* end-to-end smoke */
int main(){return 0;}