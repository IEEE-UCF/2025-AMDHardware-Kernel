/* Shader load helper (calls MGPU_LOAD_SHADER) skeleton */
